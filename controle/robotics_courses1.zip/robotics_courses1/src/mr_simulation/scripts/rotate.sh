rostopic pub /gazebo/rwheel_traction_controller/command std_msgs/Float64 "data: 2"&

rostopic pub /gazebo/lwheel_traction_controller/command std_msgs/Float64 "data: -2"
